﻿namespace BeyzaMVC.Models
{
    public class BMI_Model
    {
        public float Weight { get; set; }
        public float Height { get; set; }
        public float BMI { get; set; }
        public string Result { get; set; }


    }
}
