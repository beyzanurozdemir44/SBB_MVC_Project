﻿namespace BeyzaMVC.Models
{
    public class AppModel
    {
        public string? Name { get; set; }
        public string? Url { get; set; }
        public string? Background { get; set; }
        public string? BgColor { get; set; }

        public string? Text { get; set; }


    }
}
