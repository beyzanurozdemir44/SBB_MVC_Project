﻿namespace BeyzaMVC.Models
{
    public class QuoteModel
    {
        public string q { get; set; }
        public string a { get; set; }
        public int c { get; set; }
        public string h { get; set; }
    }
}
