﻿namespace BeyzaMVC.Models
{
    public class WeatherInfo
    {
        public string CityName { get; set; }
    }
}
