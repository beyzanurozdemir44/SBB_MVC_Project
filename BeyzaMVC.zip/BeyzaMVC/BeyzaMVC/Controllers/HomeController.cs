﻿using BeyzaMVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace BeyzaMVC.Controllers
{
    public class HomeController : Controller
    {







        public IActionResult Index()
        {
            List<AppModel> AppList = new List<AppModel>()
        {
                    new AppModel { Name="BMI", Url="/BMI/BMIView", Background=@"/images/vücut.jpg", Text="Kullanıcı boy,kilo ve cinsiyetini girerek vücut kitle endeksini hesaplayabilir.", BgColor="bmicard" },
                     new AppModel { Name="TO DO LIST",Url="/ToDoList/Index", Background=@"/images/yapılacak.jpg", Text="          Kullanıcı görevlerini buraya not ederek kolayca erişebilir.", BgColor="todocard" },
                    new AppModel { Name="WEATHER", Url="/Weather/WeatherView", Background=@"/images/hava.jpeg", Text="                Kullanıcı istediği şehri aratarak hava durumunu öğrenebilir.", BgColor="weathercard" },
                    new AppModel { Name="QUOTES", Url="/RandomQuote/RandomQuoteView", Background=@"/images/söz.jpg",Text="Kullanıcı rastgele bir özlü söze ulaşabilir ve twitter hesabında paylaşabilir.", BgColor="quotescard" },


        };
            return View(AppList);
        }

        public IActionResult Privacy()
        {

            return View();
        }


    }
}