﻿using Microsoft.AspNetCore.Mvc;
using BeyzaMVC.Models;
using Newtonsoft.Json;

namespace BeyzaMVC.Controllers
{
    public class RandomQuoteController : Controller
    {
        public IActionResult RandomQuoteView()//
        {
            return View();
        }
        [HttpGet]
        public JsonResult Api()
        {

            List<QuoteModel> quotes = new List<QuoteModel>();
            string Url = "https://zenquotes.io/api/quotes";


            //
            HttpClient client = new HttpClient();
            HttpResponseMessage response = client.GetAsync(Url).Result;

            if (response.IsSuccessStatusCode)
            {
                quotes = JsonConvert.DeserializeObject<List<QuoteModel>>(response.Content.ReadAsStringAsync().Result);
            }
           
            int listLength = quotes.Count();
            int randomNumber = CreateRandomNumber(listLength);

            return Json(quotes[randomNumber]);
        }
        public int CreateRandomNumber(int n)
        {
            Random randomNumber = new Random();
            int number = randomNumber.Next(n);
            return number;
        }

    }
}
